import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class CapturaTeclaC extends JFrame {

    private JList<String> lista;
    private DefaultListModel<String> modeloLista;
    private JButton boton;

    public CapturaTeclaC() {
        setTitle("Captura de tecla C");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        modeloLista = new DefaultListModel<>();
        modeloLista.addElement("Elemento 1");
        modeloLista.addElement("Elemento 2");
        modeloLista.addElement("Elemento 3");
        lista = new JList<>(modeloLista);

        boton = new JButton("Botón de prueba");

        add(new JScrollPane(lista), BorderLayout.CENTER);
        add(boton, BorderLayout.SOUTH);

        lista.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyChar() == 'c' || e.getKeyChar() == 'C') {
                    int index = lista.getSelectedIndex();
                    if (index != -1) {
                        System.out.println("Tecla C detectada sobre: " + modeloLista.get(index));
                        String original = modeloLista.get(index);
                        if (!original.endsWith(" (Marcado)")) {
                            modeloLista.set(index, original + " (Marcado)");
                        } else {
                            modeloLista.set(index, original.replace(" (Marcado)", ""));
                        }
                    } else {
                        System.out.println("Tecla C detectada pero no hay elemento seleccionado.");
                    }
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CapturaTeclaC::new);
    }
}
